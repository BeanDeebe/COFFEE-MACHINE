class Main {
    public static void main(String[] args) {
        // put your code here
        System.out.println("O X X");
        System.out.println("O X O");
        System.out.println("X O X");
    }
}